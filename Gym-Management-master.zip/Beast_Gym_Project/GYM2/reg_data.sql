-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 07, 2021 at 06:33 AM
-- Server version: 5.7.31
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gym`
--

-- --------------------------------------------------------

--
-- Table structure for table `reg_data`
--

DROP TABLE IF EXISTS `reg_data`;
CREATE TABLE IF NOT EXISTS `reg_data` (
  `userid` int(25) NOT NULL AUTO_INCREMENT,
  `Name` varchar(30) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Height` varchar(10) NOT NULL,
  `Weight` varchar(100) NOT NULL,
  `Phonenumber` varchar(10) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `Pincode` varchar(10) NOT NULL,
  `Disease` varchar(50) NOT NULL,
  `State` varchar(25) NOT NULL,
  `City` varchar(25) NOT NULL,
  `Password` varchar(15) NOT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reg_data`
--

INSERT INTO `reg_data` (`userid`, `Name`, `Email`, `Height`, `Weight`, `Phonenumber`, `Address`, `Pincode`, `Disease`, `State`, `City`, `Password`) VALUES
(12, 'Sarak', 'sarak@sarak', '6', '45', '54525525', 'Gnagar', '382315', 'BP', 'Gujarat', 'Dehgam', '123456'),
(14, 'nisarg', 'nisarg@nisarg', '6', '95', '9898664455', 'himmitnagar', '380001', 'chorlestore', 'gujarat', 'himmitnagar', '12345'),
(10, 'Rahul', 'raval.rahul@gmail.com', '4', '50', '635525152', 'himmitnagar', '380001', 'null', 'gujarat', 'himmitnagar', '1234'),
(13, 'Akshay', 'Askhay@ak', '6', '95', '85458255', 'himmitnagar', '380001', 'Disease', 'Gujarat', 'Gandhinagar', '1234'),
(15, 'Tiski', 'tiski123@gmail.com', '6', '65', '9977445589', 'Tiski', '909091', 'null', 'gujarat', 'modasa', 'tiski@3');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
