<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Admin\css\bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <title>Diet Plan</title>
    
   
  
</head>
<body>
    <?php include('11.php'); 
  

include "connect.php";
$id=$_SESSION['SRno'];
$sql="select * from `diet_master` where `user_id`='".$id."' ";
$query = mysqli_query($conn,$sql);
$row = mysqli_fetch_array($query);

if ($query->num_rows > 0){


$_SESSION['b_mon']=$row['b_monday'];
$_SESSION['l_mon']=$row['l_monday'];
$_SESSION['d_mon']=$row['d_monday'];
$_SESSION['b_tue']=$row['b_tuesday'];
$_SESSION['l_tue']=$row['l_tuesday'];
$_SESSION['d_tue']=$row['d_tuesday'];
$_SESSION['b_wed']=$row['b_wednesday'];
$_SESSION['l_wed']=$row['l_wednesday'];
$_SESSION['d_wed']=$row['d_wednesday'];
$_SESSION['b_thu']=$row['b_thursday'];
$_SESSION['l_thu']=$row['l_thursday'];
$_SESSION['d_thu']=$row['d_thursday'];
$_SESSION['b_fri']=$row['b_friday'];
$_SESSION['l_fri']=$row['l_friday'];
$_SESSION['d_fri']=$row['d_friday'];
$_SESSION['b_sat']=$row['b_saturday'];
$_SESSION['l_sat']=$row['l_saturday'];
$_SESSION['d_sat']=$row['d_saturday'];
$_SESSION['b_sun']=$row['b_sunday'];
$_SESSION['l_sun']=$row['l_sunday'];
$_SESSION['d_sun']=$row['d_sunday'];

}
else{
    echo '<script>alert("Data Is Not Available");</script>';
    $_SESSION['b_mon']="none";
$_SESSION['l_mon']= "none";
$_SESSION['d_mon']= "none";
$_SESSION['b_tue']= "none";
$_SESSION['l_tue']= "none";
$_SESSION['d_tue']= "none";
$_SESSION['b_wed']= "none";
$_SESSION['l_wed']= "none";
$_SESSION['d_wed']= "none";
$_SESSION['b_thu']= "none";
$_SESSION['l_thu']= "none";
$_SESSION['d_thu']= "none";
$_SESSION['b_fri']= "none";
$_SESSION['l_fri']= "none";
$_SESSION['d_fri']= "none";
$_SESSION['b_sat']= "none";
$_SESSION['l_sat']= "none";
$_SESSION['d_sat']= "none";
$_SESSION['b_sun']= "none";
$_SESSION['l_sun']= "none";
$_SESSION['d_sun']= "none";
}



mysqli_close($conn);

?>

    <h2 style="color:Black; font-size:50px; text-align:center; margin-bottom:50px; margin-top:40px;" >Diet Plan </h2>           
    <form action="#" method="post">
  
    <table style="height: 300px; margin-left:25%; width:70%; color:black;" class="table table-bordered">
    <thead>
      <tr style="color:#888; font-size:20px; text-align:center;"  >
        <th>Day & Time</th>
        <th>Monday</th>
        <th>Tuesday</th>
        <th>Wednesday</th>
        <th>Thursday</th>
        <th>Friday</th>
        <th>Saturday</th>
        <th>Sunday</th>
      </tr>
    </thead>
    <tbody>
      <tr style="color:black; font-size:15px;">
        <td>BREAKFAST</td>
        <td> <label name="b_monday"> <?php echo $_SESSION['b_mon']; ?> </label></td>
        <td> <label name="b_tuesday"> <?php echo $_SESSION['b_tue']; ?> </label></td>
        <td> <label name="b_wednesday"> <?php echo $_SESSION['b_wed']; ?> </label></td>
        <td> <label name="b_thursday"> <?php echo $_SESSION['b_thu']; ?> </label></td>
        <td> <label name="b_friday"> <?php echo $_SESSION['b_fri']; ?> </label></td>
        <td> <label name="b_saturday"> <?php echo $_SESSION['b_sat']; ?> </label></td>
        <td> <label name="b_sunday"> <?php echo $_SESSION['b_sun']; ?> </label></td>
        
      </tr>
      <tr style="color:black; font-size:15px;">
        <td>LUNCH</td>
        <td> <label name="l_monday"> <?php echo $_SESSION['l_mon']; ?> </label></td>
        <td> <label name="l_tuesday"> <?php echo $_SESSION['l_tue']; ?> </label></td>
        <td> <label name="l_wednesday"> <?php echo $_SESSION['l_wed']; ?> </label></td>
        <td> <label name="l_thursday"> <?php echo $_SESSION['l_thu']; ?> </label></td>
        <td> <label name="l_friday"> <?php echo $_SESSION['l_fri']; ?> </label></td>
        <td> <label name="l_saturday"> <?php echo $_SESSION['l_sat']; ?> </label></td>
        <td> <label name="l_sunday"> <?php echo $_SESSION['l_sun']; ?> </label></td>
      </tr>
      <tr style="color:black; font-size:15px;">
        <td>DINNER</td>
        <td> <label name="d_monday"> <?php echo $_SESSION['d_mon']; ?> </label></td>
        <td> <label name="d_tuesday"> <?php echo $_SESSION['d_tue']; ?> </label></td>
        <td> <label name="d_wednesday"> <?php echo $_SESSION['d_wed']; ?> </label></td>
        <td> <label name="d_thursday"> <?php echo $_SESSION['d_thu']; ?> </label></td>
        <td> <label name="d_friday"> <?php echo $_SESSION['d_fri']; ?> </label></td>
        <td> <label name="d_saturday"> <?php echo $_SESSION['d_sat']; ?> </label></td>
        <td> <label name="d_sunday"> <?php echo $_SESSION['d_sun']; ?> </label></td>
      </tr>
    </tbody>
  </table> 
</form>
</body>
</html>


