<?php

if(isset($_POST['Login']))
{
  $uname=$_POST['Name'];
  $upass=$_POST['Password'];
 


     if($uname==null && $upass==null)
   {
      echo '<script>alert("please enter Name and Password Either go to the Registration page")</script>';
   }
    else
   {
       session_start();
       $server = "localhost";
       $username = "root";
       $password= "";
       $database = "gym";


      $conn = mysqli_connect($server, $username, $password, $database);
   

       

       $sql="select * from `reg_data` where `Name`='".$uname."' AND `Password`='".$upass."'";
       $query = mysqli_query($conn,$sql);
       $row = mysqli_fetch_array($query);
       if($row['Name']==$uname && $row['Password']==$upass)
       {
        $_SESSION['SRno']=$row['userid'];
   
       
        header("location:11.php");
       }
        else
        {
            echo '<script>alert("Can not match here in database please try again")</script>';
            session_unset();
            session_destroy();
        }
        mysqli_free_result($query);
        mysqli_close($conn);
     }
    }


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="login.css">
</head>
<body>
<?php include('header.php')?>
        <div class="wrap">
            <form action="" method="POST">
            <h1>Login</h1>
            <input name="Name" type="text" placeholder="Name" id="Name" required>
            <input name="Password" type="password" placeholder="Password" id="Password" required>
            <button name="Login" type="submit" class="loginbtn">Login</button>
            <p>Don't have Account <a href="user_reg.php">Sign Up</a>.</p>
            </form>
        </div>
        <div class="footer">
        <?php
        include "footer.php";
        ?>
    </div>
</body>
</html>