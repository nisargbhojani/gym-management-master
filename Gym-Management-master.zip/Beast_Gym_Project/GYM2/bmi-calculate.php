<!DOCTYPE html>
<html>
<head>
<title>BMI CALCULATE</title>
<link rel="stylesheet" href="bmi.css">
</head>
<body>
    <?php
    include('11.php')
    ?>
    <div class="container">
<form method="GET" action="bmi.php">
<div class="wrap">
        <h1>BMI Calculator</h1>         
        <input type="text" name="mass" placeholder="Mass in Kg" id="mass" required>        
        <input type="text" name="height" placeholder="Height in Meter" id="email" required>              
        <!-- <input type="submit" name="submit" value="submit">  -->
        <button type="submit" name="submit"  class="submit" value="submit">Submit</button>
    </div>
<!-- Mass in kilogram (kg):-
<input type="text" name="mass">
Height in meter (m):-
<input type="text" name="height">
<input type="submit" name="submit" value="submit"> -->
</form>
</div>
</body>
</html>