<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Admin\css\bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <title>Diet Plan</title>
    
  
</head>
<body>
    <?php include('11.php'); 
  

include "connect.php";
$id=$_SESSION['SRno'];
$sql="select * from `exe_master` where `user_id`='".$id."' ";
$query = mysqli_query($conn,$sql);
$row = mysqli_fetch_array($query);

if ($query->num_rows > 0){


$_SESSION['s1_mon']=$row['s1_monday'];
$_SESSION['s2_mon']=$row['s2_monday'];
$_SESSION['s3_mon']=$row['s3_monday'];
$_SESSION['s1_tue']=$row['s1_tuesday'];
$_SESSION['s2_tue']=$row['s2_tuesday'];
$_SESSION['s3_tue']=$row['s3_tuesday'];
$_SESSION['s1_wed']=$row['s1_wednesday'];
$_SESSION['s2_wed']=$row['s2_wednesday'];
$_SESSION['s3_wed']=$row['s3_wednesday'];
$_SESSION['s1_thu']=$row['s1_thursday'];
$_SESSION['s2_thu']=$row['s2_thursday'];
$_SESSION['s3_thu']=$row['s3_thursday'];
$_SESSION['s1_fri']=$row['s1_friday'];
$_SESSION['s2_fri']=$row['s2_friday'];
$_SESSION['s3_fri']=$row['s3_friday'];
$_SESSION['s1_sat']=$row['s1_saturday'];
$_SESSION['s2_sat']=$row['s2_saturday'];
$_SESSION['s3_sat']=$row['s3_saturday'];
$_SESSION['s1_sun']=$row['s1_sunday'];
$_SESSION['s2_sun']=$row['s2_sunday'];
$_SESSION['s3_sun']=$row['s3_sunday'];

}
else{
    echo '<script>alert("Data Is Not Available");</script>';
$_SESSION['s1_mon']="none";
$_SESSION['s2_mon']= "none";
$_SESSION['s3_mon']= "none";
$_SESSION['s1_tue']= "none";
$_SESSION['s2_tue']= "none";
$_SESSION['s3_tue']= "none";
$_SESSION['s1_wed']= "none";
$_SESSION['s2_wed']= "none";
$_SESSION['s3_wed']= "none";
$_SESSION['s1_thu']= "none";
$_SESSION['s2_thu']= "none";
$_SESSION['s3_thu']= "none";
$_SESSION['s1_fri']= "none";
$_SESSION['s2_fri']= "none";
$_SESSION['s3_fri']= "none";
$_SESSION['s1_sat']= "none";
$_SESSION['s2_sat']= "none";
$_SESSION['s3_sat']= "none";
$_SESSION['s1_sun']= "none";
$_SESSION['s2_sun']= "none";
$_SESSION['s3_sun']= "none";
}



mysqli_close($conn);

?>

    <h2 style="color:Black; font-size:50px; text-align:center; margin-bottom:50px; margin-top:40px;" >Excercise Plan </h2>           
    <form action="#" method="post">
  
    <table style="height: 300px; margin-left:25%; width:70%; color:black;" class="table table-bordered">
    <thead>
      <tr style="color:#888; font-size:20px; text-align:center;"  >
        <th>Day & Set</th>
        <th>Monday</th>
        <th>Tuesday</th>
        <th>Wednesday</th>
        <th>Thursday</th>
        <th>Friday</th>
        <th>Saturday</th>
        <th>Sunday</th>
      </tr>
    </thead>
    <tbody>
      <tr style="color:black; font-size:15px;">
        <td>Set 1</td>
        <td> <label name="b_monday"> <?php echo $_SESSION['s1_mon']; ?> </label></td>
        <td> <label name="b_tuesday"> <?php echo $_SESSION['s1_tue']; ?> </label></td>
        <td> <label name="b_wednesday"> <?php echo $_SESSION['s1_wed']; ?> </label></td>
        <td> <label name="b_thursday"> <?php echo $_SESSION['s1_thu']; ?> </label></td>
        <td> <label name="b_friday"> <?php echo $_SESSION['s1_fri']; ?> </label></td>
        <td> <label name="b_saturday"> <?php echo $_SESSION['s1_sat']; ?> </label></td>
        <td> <label name="b_sunday"> <?php echo $_SESSION['s1_sun']; ?> </label></td>
        
      </tr>
      <tr style="color:black; font-size:15px;">
        <td>Set 2</td>
        <td> <label name="l_monday"> <?php echo $_SESSION['s2_mon']; ?> </label></td>
        <td> <label name="l_tuesday"> <?php echo $_SESSION['s2_tue']; ?> </label></td>
        <td> <label name="l_wednesday"> <?php echo $_SESSION['s2_wed']; ?> </label></td>
        <td> <label name="l_thursday"> <?php echo $_SESSION['s2_thu']; ?> </label></td>
        <td> <label name="l_friday"> <?php echo $_SESSION['s2_fri']; ?> </label></td>
        <td> <label name="l_saturday"> <?php echo $_SESSION['s2_sat']; ?> </label></td>
        <td> <label name="l_sunday"> <?php echo $_SESSION['s2_sun']; ?> </label></td>
      </tr>
      <tr style="color:black; font-size:15px;">
        <td>Set 3</td>
        <td> <label name="d_monday"> <?php echo $_SESSION['s3_mon']; ?> </label></td>
        <td> <label name="d_tuesday"> <?php echo $_SESSION['s3_tue']; ?> </label></td>
        <td> <label name="d_wednesday"> <?php echo $_SESSION['s3_wed']; ?> </label></td>
        <td> <label name="d_thursday"> <?php echo $_SESSION['s3_thu']; ?> </label></td>
        <td> <label name="d_friday"> <?php echo $_SESSION['s3_fri']; ?> </label></td>
        <td> <label name="d_saturday"> <?php echo $_SESSION['s3_sat']; ?> </label></td>
        <td> <label name="d_sunday"> <?php echo $_SESSION['s3_sun']; ?> </label></td>
      </tr>
    </tbody>
  </table> 
</form>
</body>
</html>


