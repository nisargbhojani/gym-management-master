<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Plans</title>
    <link rel="stylesheet" href="plans.css">
</head>
<body>
    <?php
        include('11.php');
    ?>
    <div class="vl"></div>

    <section class="clearfix">

              <div class="project-section">

                <div class="project-container">
                  <div class="project-img-container" display='block'>
                      <a href="diet.php">
                    <img src="diet1.png" alt="project image">
                    </a>
                </div>
                  <p class="project-title">DIET PLAN</p>
                </div>

                <div class="project-container">
                  <div class="project-img-container" display='block'>
                      <a href="exe.php">
                    <img src="exe4.png" alt="project image">
                    </a>
                  </div>
                  <p class="project-title">EXCERISE PLAN</p>
                </div>

</body>
</html>