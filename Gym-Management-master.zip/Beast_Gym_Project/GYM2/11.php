<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="11.css">

    <title>Welcome To BEAST GYM</title>
</head>
<body>
    <?php 
        include ('header.php');

        session_start();
        if($_SESSION['SRno'] == null || $_SESSION['SRno'] == ""){
            header("location:home.php");
            
        }

        if (isset($_POST['signout'])){
            session_destroy();
        }

    ?>
    <div class="navigation">
        <ul>
            <li>
                <a href="userhome.php">
                    <span class="icon"><i class="fa fa-home" aria-hidden="true"></i></span>
                    <span class="title">Home</span>
                </a>
            </li>
            <li>
                <a href="userprofile.php">
                    <span class="icon"><i class="fa fa-user" aria-hidden="true"></i></span>
                    <span class="title">Profile</span>
                </a>
            </li>
            <li>
                <a href="plans.php">
                    <span class="icon"><i class="fa fa-columns" aria-hidden="true"></i></span>
                    <span class="title">Plans</span>
                </a>
            </li>
            <li>
                <a href="exceriseplan.php">
                    <span class="icon"><i class="fa fa-universal-access" aria-hidden="true"></i></span>
                    <span class="title">Excercise</span>
                </a>
            </li>
            <li>
                <a href="bmi-calculate.php">
                    <span class="icon"><i class="fa fa-calculator" aria-hidden="true"></i></span>
                    <span class="title">Calculate BMI</span>
                </a>
            </li>
            <li>
                <a href="bmr.php">
                    <span class="icon"><i class="fa fa-calculator" aria-hidden="true"></i></span>
                    <span class="title">Calculate BMR</span>
                </a>
            </li>
            <li>
                <a href="help.php">
                    <span class="icon"><i class="fa fa-question-circle" aria-hidden="true"></i></span>
                    <span class="title">Help</span>
                </a>
            </li>
            <li>
                <a href="forgotpw.php">
                    <span class="icon"><i class="fa fa-cog" aria-hidden="true"></i></span>
                    <span class="title">Change Password</span>
                </a>
            </li>
            <li>
                <a>
                    <span class="icon"><i class="fa fa-sign-out" aria-hidden="true"></i></span>
                    <!-- <span class="title">Sign Out</span> -->
                    <form action="" method="POST">
                        <button name="signout" class="title" style="display: inline-block; background-color: transparent; border: none; color:white; font-size: 16px;">Sign Out</button>
                    </form>

                </a>
            </li>
        </ul>
    </div>
    
</body>
</html>