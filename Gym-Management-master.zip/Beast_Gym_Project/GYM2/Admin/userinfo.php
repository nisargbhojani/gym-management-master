<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <title>Admin Dashboard</title>
</head>
<body>
<?php 
    include('header.php');   
    include ('admin_con.php')                                            
 ?>
<div class="table">
    <div>
        <h1 style="color:white; text-align:center; margin-bottom:50px;">Users Information</h1>
    </div>
    <?php
                $query = "SELECT * FROM    reg_data";
                $query_run = mysqli_query($conn, $query);
            ?>
<table class="table table-bordered" id="dataTable" width="50%" cellspacing="0">
                    <thead>
                        <tr style="color:skyblue;">
                            <th> ID </th>
                            <th> Username </th>
                            <th>User-Email</th>                            
                            <th>Disease</th>                            
                            <th>Diet</th>
                            <th>Exercise</th>
                        </tr>
                    </thead>
                    <tbody style="color:white;">
                        <?php
                        if(mysqli_num_rows($query_run) > 0)        
                        {
                            while($row = mysqli_fetch_assoc($query_run))
                            {
                      
                            echo "<tr>";
                                echo "<td>". $row['userid']."</td>";
                                echo "<td>". $row['Name'] ."</td>";
                                echo "<td>". $row['Email'] ."</td>";
                                echo "<td>". $row['Disease'] ."</td>";
                                // echo "<td style='width:200px; text-align:center;'><button name='btn_diet' id=".$row['userid']." style=' margin:auto; border:none; color:white; padding:5px 10px; background-color:#8e44ad;'>Set Diet Plan</button></td>";
                                echo "<td style='width:200px; text-align:center;'><a href='diet_upload.php?id=".$row['userid']."' style=' margin:auto; border:none; color:white; padding:5px 10px; background-color:#8e44ad;'>Set Diet Plan</a></td>";
                                echo "<td style='width:200px; text-align:center;'><a href='exe_upload.php?id=".$row['userid']."'style=' margin:auto; border:none; color:white; padding:5px 10px; background-color:#8e44ad;'>Set Excercise Plan</a></td>";
                            }
                        } 
                            
                            echo "</tr>";
                            
                      ?>      
                            </tbody>                  
</table> 
</div> 
<?php 
    include('footer.php');                                               
 ?>
</body>                                                                                                                                                                                     
</html>

<?php 

if(isset($_POST['btn_diet']))
{
    
}
?>