<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Help Section</title>
    <style>
        #heading{
            color:white;
            margin-bottom:100px;
            font-size:60px;
            text-align:center;
        }
        #footer{
            color:white;
            text-align:center;
        }
    </style>
</head>
<body>
    <?php include('header.php')?>
    
    <h1 id="heading">Chat With CLIENTS</h1>
    <h6 id="footer">******************************// Currently Under-Construction //******************************</h6>

    <?php include('footer.php')?>
</body>
</html>