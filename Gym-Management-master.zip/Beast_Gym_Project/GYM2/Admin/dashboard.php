<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/admin.css">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-xl-2 col-lg-3 col-md-3 col-sm-12 side-bar" id="side-bar">
                    <div class="logo">
                        <a href="#">Admin Panel</a>
                        <div class="burger" id="burger">
                            <div class="b"></div>
                            <div class="b"></div>
                            <div class="b"></div>
                        </div>
                    </div>
                    <div class="side-menu" id="side-menu">
                        <ul>
                            <li><a href="#">Dashboard</a></li>
                            <li><a href="userinfo.php">Users</a></li>
                            <li><a href="#">Help</a></li>
                            <!-- <li><a href="#">Feedback</a></li> -->
                            <li><a href="#">FAQs</a></li>
                            <!-- <li><a href="#">Manage User</a></li> -->
                        </ul>

                    </div>

            </div>
            <div class="col-xl-10 col-lg-9 col-md-9 col-sm-12">
                <div class="row">
                    <div class="col-lg-12 col-md-12 header">
                        <div class="user-profile">
                            <ul>
                                <li>
                                    <a href="#"><i class="fa fa-user"></i> Admin </a>
                                    <ul class="sub-menu">
                                        <li><a href="#">Profile</a></li>
                                        <li><a href="#">Log out</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="row">
                <div class="col-lg-12 col-md-12">
                <h1 style="color:white; margin-top:50px; text-align:center; font-size:65px; ">WELCOME TO ADMIN PANEL</h1>
                </div>                
                

                </div>
            </div>
        </div>
    </div>
</body>
<script src="js/master.js"></script>
</html>