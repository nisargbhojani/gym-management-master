<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin reg</title>
    <link rel="stylesheet" href="admin_reg.css">
</head>
<body>
   
    <div class="wrap">
        <h1>Register</h1> 
       
        <form action="" method="POST">
        
        <input name="Name" type="text" placeholder="Name" id="Name" required>  

        <input name="Email" type="text" placeholder="Email" id="Email" required>    

        <input name="Password" type="password" placeholder="Password" id="Password" required>    

        <button name="submit" type="submit" class="registerbtn">Register</button>

         <p>Already have an acoount? <a href="signin.php">Sign in</a>.</p> 
    
    </div>
    <div class="footer">
        <?php
       // include "footer.php";
        include "admin_con.php";
        ?>
    </div>
</body>
</html>

<?php

if (isset($_POST['submit'])){
  
   
    $Name = $_POST['Name'];
    $Email = $_POST['Email'];
   $Password = $_POST['Password'];





    $sql = "INSERT INTO `admin_reg` VALUES (NULL,'$Name', '$Email', '$Password' )";
    $result = mysqli_query($conn, $sql);

    if($result){
      echo '<script>alert("Successfull")</script>';
      //header("location: login.php");
    }

    else{
        // echo "The record was not inserted successfully because of this error ---> ". mysqli_error($conn);
        echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
      <strong>Error!</strong> We are facing some technical issue and your entry ws not submitted successfully! We regret the inconvinience caused!
      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">×</span>
      </button>
    </div>';
    }

  
  

} 