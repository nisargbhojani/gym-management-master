document.getElementById("burger").addEventListener("click",()=>{
    document.getElementById("side-bar").classList.toggle("side-bar-t");
    document.getElementById("side-menu").classList.toggle("side-menu-t");
});