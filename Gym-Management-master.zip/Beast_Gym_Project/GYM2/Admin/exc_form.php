<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <style>
    *{
        color:skyblue;
    }
    </style>

</head>
<body>
    <?php
        include('header.php')    
    ?>
    <form action="#">
    
    <input name="excercise_upload" type="file" placeholder="Upload Here" id="excercise_upload" style='margin:auto; margin-bottom:100px; margin-top:100px; display:block; ' required > 
    <button name='btn_excercise' style=' margin:auto; display:block; border:none; color:white; padding:5px 10px; background-color:#8e44ad;'>Submit</button>
    </form>




    <?php
        include('footer.php')    
    ?>
</body>
</html>