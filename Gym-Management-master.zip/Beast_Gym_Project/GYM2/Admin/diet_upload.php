<!DOCTYPE html>
<html lang="en">
<head>
  <title>Change Diet Plan</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>
<?php include('header.php'); include('admin_con.php'); ?>
  <h2 style="color:white; font-size:50px; text-align:center; margin-bottom:50px" >Diet Plan </h2>           
<form action="#" method="post">
  
  <table style="height: 300px; width:100%;" class="table table-bordered">
    <thead>
      <tr style="color:skyblue; font-size:20px;">
        <th>Day & Time</th>
        <th>Monday</th>
        <th>Tuesday</th>
        <th>Wednesday</th>
        <th>Thursday</th>
        <th>Friday</th>
        <th>Saturday</th>
        <th>Sunday</th>
      </tr>
    </thead>
    <tbody>
      <tr style="color:skyblue; font-size:15px;">
        <td>BREAKFAST</td>
        <td><textarea id="w3review" name="b_monday" rows="1" cols="10"></textarea></td>
        <td><textarea id="w3review" name="b_tuesday" rows="1" cols="10"></textarea></td>
        <td><textarea id="w3review" name="b_wednesday" rows="1" cols="10"></textarea></td>
        <td><textarea id="w3review" name="b_thursday" rows="1" cols="10"></textarea></td>
        <td><textarea id="w3review" name="b_friday" rows="1" cols="10"></textarea></td>
        <td><textarea id="w3review" name="b_saturday" rows="1" cols="10"></textarea></td>
        <td><textarea id="w3review" name="b_sunday" rows="1" cols="10"></textarea></td>
        
      </tr>
      <tr style="color:skyblue; font-size:15px;">
        <td>LUNCH</td>
        <td><textarea id="w3review" name="l_monday" rows="1" cols="10"></textarea></td>
        <td><textarea id="w3review" name="l_tuesday" rows="1" cols="10"></textarea></td>
        <td><textarea id="w3review" name="l_wednesday" rows="1" cols="10"></textarea></td>
        <td><textarea id="w3review" name="l_thursday" rows="1" cols="10"></textarea></td>
        <td><textarea id="w3review" name="l_friday" rows="1" cols="10"></textarea></td>
        <td><textarea id="w3review" name="l_saturday" rows="1" cols="10"></textarea></td>
        <td><textarea id="w3review" name="l_sunday" rows="1" cols="10"></textarea></td>
      </tr>
      <tr style="color:skyblue; font-size:15px;">
        <td>DINNER</td>
        <td><textarea id="w3review" name="d_monday" rows="1" cols="10"></textarea></td>
        <td><textarea id="w3review" name="d_tuesday" rows="1" cols="10"></textarea></td>
        <td><textarea id="w3review" name="d_wednesday" rows="1" cols="10"></textarea></td>
        <td><textarea id="w3review" name="d_thursday" rows="1" cols="10"></textarea></td>
        <td><textarea id="w3review" name="d_friday" rows="1" cols="10"></textarea></td>
        <td><textarea id="w3review" name="d_saturday" rows="1" cols="10"></textarea></td>
        <td><textarea id="w3review" name="d_sunday" rows="1" cols="10"></textarea></td>
      </tr>
    </tbody>
  </table> 

<button style=' margin:auto; border:none; color:white; padding:5px 10px; background-color:#8e44ad;' id="submit" name="btn_diet_upload">SUBMIT</button>


</form>
<?php include('footer.php'); ?>
</body>
</html>


<?php 
  
  //  $_GET['id'];

  if(isset($_POST["btn_diet_upload"]))
  {
    $b_mon = $_POST['b_monday'];
    $l_mon = $_POST['l_monday'];
    $d_mon = $_POST['d_monday'];
    $b_tue = $_POST['b_tuesday'];
    $l_tue = $_POST['l_tuesday'];
    $d_tue = $_POST['d_tuesday'];
    $b_wed = $_POST['b_wednesday'];
    $l_wed = $_POST['l_wednesday'];
    $d_wed = $_POST['d_wednesday'];
    $b_thu = $_POST['b_thursday'];
    $l_thu = $_POST['l_thursday'];
    $d_thu = $_POST['d_thursday'];
    $b_fri = $_POST['b_friday'];
    $l_fri = $_POST['l_friday'];
    $d_fri = $_POST['d_friday'];
    $b_sat = $_POST['b_saturday'];
    $l_sat = $_POST['l_saturday'];
    $d_sat = $_POST['d_saturday'];
    $b_sun = $_POST['b_sunday'];
    $l_sun = $_POST['l_sunday'];
    $d_sun = $_POST['d_sunday'];

$id=$_GET['id'];




    $sql = "INSERT INTO `diet_master` VALUES (NULL,'$id', '$b_mon', '$l_mon', '$d_mon', '$b_tue', '$l_tue', '$d_tue', '$b_wed', '$l_wed', '$d_wed', '$b_thu', '$l_thu', '$d_thu', '$b_fri', '$l_fri', '$d_fri', '$b_sat', '$l_sat', '$d_sat', '$b_sun', '$l_sun', '$d_sun' )";
    $result = mysqli_query($conn, $sql);

    if($result){
      echo '<script>alert("Successfull")</script>';
    
    }

    else{
        // echo "The record was not inserted successfully because of this error ---> ". mysqli_error($conn);
        echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
      <strong>Error!</strong> We are facing some technical issue and your entry ws not submitted successfully! We regret the inconvinience caused!
      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">×</span>
      </button>
    </div>';
    }
  }
?>
