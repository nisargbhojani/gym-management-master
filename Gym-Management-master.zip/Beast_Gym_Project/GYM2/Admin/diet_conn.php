<?php

// include('admin_con.php');

// if(isset($_POST['save_image']))
// {
//     $images = $_FILES['diet_image']['name'];

    
//  if(file_exists("upload/" . $_FILES["diet_image"]["name"]))
//   {
//         $store = $_FILES["diet_image"]["name"];
//         $_SESSION['status']= "Image already exist.'.$store.'";
//         header('Location: diet_form.php'); 
//   }
//   else
//   {
//     $query = "INSERT INTO diet ('images') VALUES ('$images')";
//     $query = mysqli_query($connection, $query);

//     if ($query_run) 
//     {
//         move_uploaded_file($_FILES["diet_image"]["tmp_name"], "upload/".$_FILES["file"]["name"]);
//         $_SESSION['success'] = "Image Uploaded";
//         header('Location: diet_form.php');
//     } 
//     else 
//     {
//         $_SESSION['success'] = "image not Uploaded";
//         header('Location: diet_form.php');
//     }
   
//   }
    
// }
?>