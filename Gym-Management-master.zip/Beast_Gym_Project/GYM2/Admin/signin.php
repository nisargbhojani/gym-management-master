<?php

if(isset($_POST['signin']))
{
  $uname=$_POST['Name'];
  $upass=$_POST['Password'];
 
     if($uname==null && $upass==null)
   {
      echo '<script>alert("please enter  eamil and password either go to the registration page")</script>';
   }
    else
   {
       session_start();
       $server = "localhost";
       $username = "root";
       $password= "";
       $database = "gym";


      $conn = mysqli_connect($server, $username, $password, $database);
   

       
     // $id=$_SESSION['Srno'];
      //$sql="select * from `admin_reg` where `userid`='".$id."' ";

       $sql="select * from `admin_reg` where `Name`='".$uname."' AND `Password`='".$upass."'";
       $query = mysqli_query($conn,$sql);
       $row = mysqli_fetch_array($query);
       if($row['Name']==$uname && $row['Password']==$upass)
       {
        $_SESSION['Srno']=$row['Srno'];
       
        // header("Location: admin_reg.php");
       // header("Location: Admin/dashboard.html");
       echo '<script>alert("Nikal bsdk")</script>';
        
       }
        else
        {
            echo '<script>alert("Can not match here in database please try again")</script>';
            session_unset();
            session_destroy();
        }
        mysqli_free_result($query);
        mysqli_close($conn);
     }
    }


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Signin</title>
    <link rel="stylesheet" href="signin.css">
</head>
<body>
        <div class="wrap">
            <form action="" method="POST">
            <h1>Login</h1>
            <input name="Name" type="text" placeholder="Name" id="Name" required>
            <input name="Password" type="password" placeholder="Password" id="Password" required>
            <button name="signin" type="submit" class="loginbtn">Login</button>
            <p>Don't have Account <a href="admin_reg.php">Sign Up</a>.</p>
            </form>
        </div>
        
   
</body>
</html>