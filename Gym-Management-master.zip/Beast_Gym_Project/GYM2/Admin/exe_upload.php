<!DOCTYPE html>
<html lang="en">
<head>
  <title>Change Excercise Plan</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>
<?php include('header.php'); include('admin_con.php'); ?>
  <h2 style="color:white; font-size:50px; text-align:center; margin-bottom:50px" >Excercise Plan</h2>           
<form action="#" method="post">
  
  <table style="height: 300px; width:100%;" class="table table-bordered">
    <thead>
      <tr style="color:skyblue; font-size:20px; text-align:center;">
        <th>Day & Set</th>
        <th>Monday</th>
        <th>Tuesday</th>
        <th>Wednesday</th>
        <th>Thursday</th>
        <th>Friday</th>
        <th>Saturday</th>                           
        <th>Sunday</th>
      </tr>
    </thead>
    <tbody>
      <tr style="color:skyblue; font-size:15px;">
        <td>Set-1</td>
        <td><textarea id="w3review" name="s1_monday" rows="1" cols="10"></textarea></td>
        <td><textarea id="w3review" name="s1_tuesday" rows="1" cols="10"></textarea></td>
        <td><textarea id="w3review" name="s1_wednesday" rows="1" cols="10"></textarea></td>
        <td><textarea id="w3review" name="s1_thursday" rows="1" cols="10"></textarea></td>
        <td><textarea id="w3review" name="s1_friday" rows="1" cols="10"></textarea></td>
        <td><textarea id="w3review" name="s1_saturday" rows="1" cols="10"></textarea></td>
        <td><textarea id="w3review" name="s1_sunday" rows="1" cols="10"></textarea></td>
        
      </tr>
      <tr style="color:skyblue; font-size:15px;">
        <td>Set-2</td>
        <td><textarea id="w3review" name="s2_monday" rows="1" cols="10"></textarea></td>
        <td><textarea id="w3review" name="s2_tuesday" rows="1" cols="10"></textarea></td>
        <td><textarea id="w3review" name="s2_wednesday" rows="1" cols="10"></textarea></td>
        <td><textarea id="w3review" name="s2_thursday" rows="1" cols="10"></textarea></td>
        <td><textarea id="w3review" name="s2_friday" rows="1" cols="10"></textarea></td>
        <td><textarea id="w3review" name="s2_saturday" rows="1" cols="10"></textarea></td>
        <td><textarea id="w3review" name="s2_sunday" rows="1" cols="10"></textarea></td>
      </tr>
      <tr style="color:skyblue; font-size:15px;">
        <td>Set-3</td>                                                                                                                                                                                                                                                                                  
        <td><textarea id="w3review" name="s3_monday" rows="1" cols="10"></textarea></td>
        <td><textarea id="w3review" name="s3_tuesday" rows="1" cols="10"></textarea></td>
        <td><textarea id="w3review" name="s3_wednesday" rows="1" cols="10"></textarea></td>
        <td><textarea id="w3review" name="s3_thursday" rows="1" cols="10"></textarea></td>
        <td><textarea id="w3review" name="s3_friday" rows="1" cols="10"></textarea></td>
        <td><textarea id="w3review" name="s3_saturday" rows="1" cols="10"></textarea></td>
        <td><textarea id="w3review" name="s3_sunday" rows="1" cols="10"></textarea></td>
      </tr>
    </tbody>
  </table> 

<button style=' margin:auto; border:none; color:white; padding:5px 10px; background-color:#8e44ad;' id="submit" name="btn_exe_upload">SUBMIT</button>


</form>
<?php include('footer.php'); ?>
</body>
</html>


<?php 
  
   $_GET['id'];

  if(isset($_POST["btn_exe_upload"]))
  {
    $s1_mon = $_POST['s1_monday'];
    $s2_mon = $_POST['s2_monday'];
    $s3_mon = $_POST['s3_monday'];
    $s1_tue = $_POST['s1_tuesday'];
    $s2_tue = $_POST['s2_tuesday'];
    $s3_tue = $_POST['s3_tuesday'];
    $s1_wed = $_POST['s1_wednesday'];
    $s2_wed = $_POST['s2_wednesday'];
    $s3_wed = $_POST['s3_wednesday'];
    $s1_thu = $_POST['s1_thursday'];
    $s2_thu = $_POST['s2_thursday'];
    $s3_thu = $_POST['s3_thursday'];
    $s1_fri = $_POST['s1_friday'];
    $s2_fri = $_POST['s2_friday'];
    $s3_fri = $_POST['s3_friday'];
    $s1_sat = $_POST['s1_saturday'];
    $s2_sat = $_POST['s2_saturday'];
    $s3_sat = $_POST['s3_saturday'];
    $s1_sun = $_POST['s1_sunday'];
    $s2_sun = $_POST['s2_sunday'];
    $s3_sun = $_POST['s3_sunday'];

$id=$_GET['id'];




    $sql = "INSERT INTO `exe_master` VALUES (NULL,'$id', '$s1_mon', '$s2_mon', '$s3_mon', '$s1_tue', '$s2_tue', '$s3_tue', '$s1_wed', '$s2_wed', '$s3_wed', '$s1_thu', '$s2_thu', '$s3_thu', '$s1_fri', '$s2_fri', '$s3_fri', '$s1_sat', '$s2_sat', '$s3_sat', '$s1_sun', '$s2_sun', '$s3_sun' )";
    $result = mysqli_query($conn, $sql);

    if($result){
      echo '<script>alert("Successfull")</script>';
    
    }

    else{
        // echo "The record was not inserted successfully because of this error ---> ". mysqli_error($conn);
        echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
      <strong>Error!</strong> We are facing some technical issue and your entry ws not submitted successfully! We regret the inconvinience caused!
      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">×</span>
      </button>
    </div>';
    }
  }
?>
