<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Reg</title>
    <link rel="stylesheet" href="user_reg.css">
</head>
<body>
    <?php
    include('header.php')
    ?>                                                                                  
    <div class="wrap">                                        
        <h1>Register</h1> 
       
        <form action="" method="POST">
        
        <input name="name" type="text" placeholder="Name" id="name" required>  

        <input name="email" type="text" placeholder="Email examle@example.com" id="email" pattern="^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$" required>    

        <input name="height" type="text" placeholder="Height" id="height" pattern="^[0-9]*$" required>

        <input name="weight" type="number" placeholder="Weight" id="weight" required>

        <input name="Disease" type="text" placeholder="Any Disease? Not than Write NULL" id="Disease" required>

        <input name="Phonenumber" type="number" placeholder="Phone Number" id="Phonenumber" required>

        <input name="Address" type="text" placeholder="Address" id="Address" required>

        <input name="Pin-code" type="number" placeholder="Pin-code" id="Pin-code" required>        

        <input name="State" type="text" placeholder="State" id="State" required>

        <input name="City" type="text" placeholder="City" id="City" required>

        <input name="password" type="password" placeholder="Password" id="password" required>    

        <button name="submit" type="submit" class="registerbtn">Register</button>

        <p>Already have an acoount? <a href="login.php">Sign in</a>.</p>
    </div>
    <div class="footer">
        <?php
       // include "footer.php";
        include "connect.php";
        ?>
    </div>
</body>
</html>

<?php

if (isset($_POST['submit'])){
  
   
    $name = $_POST['name'];
    $email = $_POST['email'];
    $height = $_POST['height'];
    $weight = $_POST['weight'];     
    $phonenumber = $_POST['Phonenumber'];
    $Address = $_POST['Address'];
    $Pincode = $_POST['Pin-code'];  
    $Disease= $_POST['Disease'];   
    $State = $_POST['State'];
    $City = $_POST['City'];
    $password = $_POST['password'];





    $sql = "INSERT INTO `reg_data` VALUES (NULL,'$name', '$email', '$height' ,'$weight','$phonenumber','$Address','$Pincode','$Disease','$State','$City','$password' )";
    $result = mysqli_query($conn, $sql);

    if($result){
      echo '<script>alert("Successfull")</script>';
      header("location: login.php");
    }

    else{
        // echo "The record was not inserted successfully because of this error ---> ". mysqli_error($conn);
        echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
      <strong>Error!</strong> We are facing some technical issue and your entry ws not submitted successfully! We regret the inconvinience caused!
      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">×</span>
      </button>
    </div>';
    }

  
  

} 