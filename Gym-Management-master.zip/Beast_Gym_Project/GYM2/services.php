<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Services</title>
    <link rel="stylesheet" href="services.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    <?php
        include ('header.php')
    ?>
    <div class="container">
        <div class="services">
            <h1>Our Services</h1>
        </div>
        <div class="row">
            <div class="col-md-3 text-center">
                <div class="icon">
                    <i class="fa fa-desktop"></i>
                </div>
                <h3>Manage Users</h3>
                <p>Manage Users At One Place Add or Remove users as you want in Click.</p>
            </div>
            <div class="col-md-3 text-center">
                <div class="icon">
                    <i class="fa fa-file"></i>
                </div>
                <h3>Manage Plans</h3>
                <p>Manage Plans, Add and Remove Diet and Excercise Plans as you want in one click.</p>
            </div>
            <div class="col-md-3 text-center">
                <div class="icon">
                    <i class="fa fa-tablet"></i>
                </div>
                <h3>Anywhere</h3>
                <p>Access website from anywhere and anytime with any device. </p>
            </div>
            <div class="col-md-3 text-center">
                <div class="icon">
                    <i class="fa fa-archive"></i>
                </div>
                <h3>Store Tables</h3>
                <p>Store table of diet and excercise as well as change them.</p>
            </div>
        </div>
    </div>
    <div class="footer">
        <!-- <?php
        include "footer.php";
        ?> -->
    </div>
</body>
</html>