<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>
    <link rel="stylesheet" href="forgotpw.css">
</head>
<body>
    <?php
        include('11.php')
    ?>
    
    <div class="wrap">
        <h1>Change Password</h1>
        <input type="text" placeholder="Email" id="email" required>        
        <input type="password" placeholder="Password" id="password" required>
        <input type="password" placeholder="NEW Password" id="password" required>      
        <input type="password" placeholder="Confirm New Password" id="password" required>      
        <button type="submit" class="registerbtn">Change</button>        
    </div>
</body>
</html>