-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 16, 2021 at 05:42 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gym`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_reg`
--

CREATE TABLE `admin_reg` (
  `Srno` int(10) NOT NULL,
  `Name` varchar(25) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Password` varchar(15) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_reg`
--

INSERT INTO `admin_reg` (`Srno`, `Name`, `Email`, `Password`) VALUES
(6, 'Nisarg', 'nisarg123@gmail.com', 'nisarg'),
(1, 'Urmik', 'urmik123@gmail.com', 'Urmik@456'),
(2, 'Urmik', 'urmik123@gmail.com', 'Urmik@456');

-- --------------------------------------------------------

--
-- Table structure for table `contact_us`
--

CREATE TABLE `contact_us` (
  `SR no` int(25) NOT NULL,
  `Name` varchar(20) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Message` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact_us`
--

INSERT INTO `contact_us` (`SR no`, `Name`, `Email`, `Message`) VALUES
(1, 'Urmik', 'Urmik123@gmail.com', 'Hello');

-- --------------------------------------------------------

--
-- Table structure for table `diet_master`
--

CREATE TABLE `diet_master` (
  `id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL,
  `b_monday` text NOT NULL,
  `l_monday` text NOT NULL,
  `d_monday` text NOT NULL,
  `b_tuesday` text NOT NULL,
  `l_tuesday` text NOT NULL,
  `d_tuesday` text NOT NULL,
  `b_wednesday` text NOT NULL,
  `l_wednesday` text NOT NULL,
  `d_wednesday` text NOT NULL,
  `b_thursday` text NOT NULL,
  `l_thursday` text NOT NULL,
  `d_thursday` text NOT NULL,
  `b_friday` text NOT NULL,
  `l_friday` text NOT NULL,
  `d_friday` text NOT NULL,
  `b_saturday` text NOT NULL,
  `l_saturday` text NOT NULL,
  `d_saturday` text NOT NULL,
  `b_sunday` text NOT NULL,
  `l_sunday` text NOT NULL,
  `d_sunday` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `diet_master`
--

INSERT INTO `diet_master` (`id`, `user_id`, `b_monday`, `l_monday`, `d_monday`, `b_tuesday`, `l_tuesday`, `d_tuesday`, `b_wednesday`, `l_wednesday`, `d_wednesday`, `b_thursday`, `l_thursday`, `d_thursday`, `b_friday`, `l_friday`, `d_friday`, `b_saturday`, `l_saturday`, `d_saturday`, `b_sunday`, `l_sunday`, `d_sunday`) VALUES
(1, 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(2, 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(3, 0, 'jlk', 'k', 'h', 'jk', 'hjk', 'h', 'k', 'h', 'h', 'h', 'jh', 'h', 'kh', 'jh', 'h', 'kh', 'h', 'h', 'kjh', 'h', 'h'),
(5, 10, '2 boiled eggs', 'gujarati ', 'poha', '3 boiled eggs', 'punjabi', 'upma', '3 boiled eggs', 'haranvyi', 'pasta', '4 boiled eggs', 'rjsathni', 'pizza', '5 boild eggs', 'kathadiya', 'manchuriyan', '6 boiled ', 'vadapav', 'jalebi', '7 boiled', 'dabeli', 'dal-baati'),
(6, 12, 'ramesh', 'shfsd', 'iii', 'suresh', 'fefe', 'oobnjty', 'mau\ngeswg', 'bjijb', 'gufyyu', 'akhlesh', 'bjub', 'fhfy', 'esh', 'bb', 'i', 'esssh', 'bb', 'hyvhjy', 'sss', 'iii', 'uvhuk');

-- --------------------------------------------------------

--
-- Table structure for table `exe_master`
--

CREATE TABLE `exe_master` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `s1_monday` text NOT NULL,
  `s2_monday` text NOT NULL,
  `s3_monday` text NOT NULL,
  `s1_tuesday` text NOT NULL,
  `s2_tuesday` text NOT NULL,
  `s3_tuesday` text NOT NULL,
  `s1_wednesday` text NOT NULL,
  `s2_wednesday` text NOT NULL,
  `s3_wednesday` text NOT NULL,
  `s1_thursday` text NOT NULL,
  `s2_thursday` text NOT NULL,
  `s3_thursday` text NOT NULL,
  `s1_friday` text NOT NULL,
  `s2_friday` text NOT NULL,
  `s3_friday` text NOT NULL,
  `s1_saturday` text NOT NULL,
  `s2_saturday` text NOT NULL,
  `s3_saturday` text NOT NULL,
  `s1_sunday` text NOT NULL,
  `s2_sunday` text NOT NULL,
  `s3_sunday` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `exe_master`
--

INSERT INTO `exe_master` (`id`, `user_id`, `s1_monday`, `s2_monday`, `s3_monday`, `s1_tuesday`, `s2_tuesday`, `s3_tuesday`, `s1_wednesday`, `s2_wednesday`, `s3_wednesday`, `s1_thursday`, `s2_thursday`, `s3_thursday`, `s1_friday`, `s2_friday`, `s3_friday`, `s1_saturday`, `s2_saturday`, `s3_saturday`, `s1_sunday`, `s2_sunday`, `s3_sunday`) VALUES
(1, 0, 'ddwdw', 'vhj', 'vhj', 'vvhj', 'vhj', 'vdv', 'vhj', 'vhj', 'vhj', 'hj', 'vhj', 'vdv', 'vj', 'vdfvg', 'vh', 'vhj', 'vhjvh', 'vhk', 'vhjvhj', 'vdv', 'vj'),
(2, 10, 'bhb', 'bjk', 'bjkbjk', 'bbk', 'bjk', 'bjkbjk', 'bjkbjk', 'bjkbkj', 'bjbjk', 'bjb', 'bjkbjk', 'bjkbjk', 'bjk', 'bjkbjk', 'bjbjk', 'kbbjk', 'bjkbjk', 'bjkbjk', 'bn', 'bhjbjk', 'bjbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb');

-- --------------------------------------------------------

--
-- Table structure for table `reg_data`
--

CREATE TABLE `reg_data` (
  `userid` int(25) NOT NULL,
  `Name` varchar(30) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Height` varchar(10) NOT NULL,
  `Weight` varchar(100) NOT NULL,
  `Phonenumber` varchar(10) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `Pincode` varchar(10) NOT NULL,
  `Disease` varchar(50) NOT NULL,
  `State` varchar(25) NOT NULL,
  `City` varchar(25) NOT NULL,
  `Password` varchar(15) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reg_data`
--

INSERT INTO `reg_data` (`userid`, `Name`, `Email`, `Height`, `Weight`, `Phonenumber`, `Address`, `Pincode`, `Disease`, `State`, `City`, `Password`) VALUES
(12, 'Sarak', 'sarak@sarak', '6', '45', '54525525', 'Gnagar', '382315', 'BP', 'Gujarat', 'Dehgam', '123456'),
(14, 'nisarg', 'nisarg@nisarg', '6', '95', '9898664455', 'himmitnagar', '380001', 'chorlestore', 'gujarat', 'himmitnagar', '12345'),
(10, 'Rahul', 'raval.rahul@gmail.com', '4', '50', '635525152', 'himmitnagar', '380001', 'null', 'gujarat', 'himmitnagar', '1234'),
(13, 'Akshay', 'Askhay@ak', '6', '95', '85458255', 'himmitnagar', '380001', 'Disease', 'Gujarat', 'Gandhinagar', '1234'),
(15, 'Tiski', 'tiski123@gmail.com', '6', '65', '9977445589', 'Tiski', '909091', 'null', 'gujarat', 'modasa', 'tiski@3'),
(16, 'varun', 'varun@varun.com', '8', '100', '9876543210', 'Dombivilie', '3800021', 'BP', 'Maharastra', 'mumbai', '1234560'),
(17, 'Nisarg Bhojani', 'nisargbhojani123@gmail.com', '5.9', '90', '6565221', '3,Avkar society, Rakhiyal', '382315', 'null', 'Gujarat', 'Dehgam', 'nisarg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_reg`
--
ALTER TABLE `admin_reg`
  ADD PRIMARY KEY (`Srno`);

--
-- Indexes for table `contact_us`
--
ALTER TABLE `contact_us`
  ADD PRIMARY KEY (`SR no`);

--
-- Indexes for table `diet_master`
--
ALTER TABLE `diet_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exe_master`
--
ALTER TABLE `exe_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reg_data`
--
ALTER TABLE `reg_data`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_reg`
--
ALTER TABLE `admin_reg`
  MODIFY `Srno` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `contact_us`
--
ALTER TABLE `contact_us`
  MODIFY `SR no` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `diet_master`
--
ALTER TABLE `diet_master`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `exe_master`
--
ALTER TABLE `exe_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `reg_data`
--
ALTER TABLE `reg_data`
  MODIFY `userid` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
