<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us</title>
    <link rel="stylesheet" href="contact.css">
</head>
<body>
    <?php
        include ('header.php');
    ?>
    <div class="wrap">
        <h1>Contact Us</h1>
    <form action="" method="POST">
        
        <input name="Name" type="text" placeholder="Name" id="name">
        <input name="Email" type="text" placeholder="Email" id="Email">
        <input name="Message" type="text" placeholder="Write your Message" id="Message">

        <!-- <label for="subject">Subject</label> -->
        <!-- <textarea id="subject" name="subject" placeholder="Write something.." style="height:10px">
        </textarea> -->
        <input name="Submit" type="submit" class="cntbtn" value="Submit">
    </form>
    </div>
    <!-- <div class="footer">
        <?php
        include "footer.php";
        include "connect.php";
        ?>
    </div> -->
</body>
</html>

<?php

if (isset($_POST['Submit'])){
  
   
    $name = $_POST['Name'];
    $email = $_POST['Email'];
    $message = $_POST['Message'];


    $sql = "INSERT INTO `contact_us` VALUES (NULL,'$name', '$email', '$message' )";
    $result = mysqli_query($conn, $sql);

    if($result){
      echo '<script>alert("Successfull")</script>';
      //header("location: login.php");
    }

    else{
        // echo "The record was not inserted successfully because of this error ---> ". mysqli_error($conn);
        echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
      <strong>Error!</strong> We are facing some technical issue and your entry ws not submitted successfully! We regret the inconvinience caused!
      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">×</span>
      </button>
    </div>';
    }

  
  

}


?>