<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>H.I.I.T</title>
    <link rel="stylesheet" href="cardio.css">
</head>
<body>
    <?php 
        include ('11.php');
    ?>

<div id="portfolio">
            <section class="clearfix">

              <div class="project-section">

                <div class="project-container">
                  <div class="project-img-container" display='block'>
                      <a href="car_running.php">
                    <img src="images/running.png" alt="project image">
                    </a>
                </div>
                  <p class="project-title">RUNNING</p>
                </div>

                <div class="project-container">
                  <div class="project-img-container" display='block'>
                      <a href="car_walk.php">
                    <img src="images/brisk_walk.png" alt="project image">
                    </a>
                  </div>
                  <p class="project-title">BRISK WALK</p>
                </div>

                <div class="project-container">
                  <div class="project-img-container" display='block'>
                  <a href="car_jogging.php">
                    <img src="images/jogging.png" alt="project image">
                    </a>
                  </div>
                   <p class="project-title">JOGGING</p>
                </div>

                <div class="project-container">
                  <div class="project-img-container" display='block'>                  
                    <img src="images/cycling.png" alt="project image">                   
                  </div>
                   <p class="project-title">CYCLING</p>
                </div>

                <div class="project-container">
                  <div class="project-img-container" display='block'>
                  <a href="car_zumba.php">
                    <img src="images/zumba.png" alt="project image">
                    </a>
                  </div>
                   <p class="project-title">ZUMBA</p>
                </div>

                <div class="project-container">
                  <div class="project-img-container" display='block'>
                  <a href="car_jacks.php">
                    <img src="images/jumping_jacks.png" alt="project image">
                    </a>
                  </div>
                   <p class="project-title">JUMPING JACKS </p>
                </div>
</body>
</html>