<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="exceriseplan.css">
    <title>Excerise</title>
</head>
<body>
<?php 
        include ('11.php');
    ?>
<div id="portfolio">
            <section class="clearfix">

              <div class="project-section">

                <div class="project-container">
                  <div class="project-img-container" display='block'>
                      <a href="hiit.php">
                    <img src="images/hiit.png" alt="project image">
                    </a>
                </div>
                  <p class="project-title">H.I.I.T</p>
                </div>

                <div class="project-container">
                  <div class="project-img-container" display='block'>
                      <a href="cardio.php">
                    <img src="images/cardio.png" alt="project image">
                    </a>
                  </div>
                  <p class="project-title">CARDIO</p>
                </div>

                <div class="project-container">
                  <div class="project-img-container" display='block'>
                    <a href="balancing.php">
                    <img src="images/balance.png" alt="project image">
                    </a>
                  </div>                  
                   <p class="project-title">BALANCING</p>
                </div>

                <div class="project-container">
                  <div class="project-img-container" display='block'>
                    <a href="strength.php">
                    <img src="images/strength.png" alt="project image">
                    </a>
                  </div>                  
                   <p class="project-title">STRENGTH</p>
                </div>

                <div class="project-container">
                  <div class="project-img-container" display='block'>
                    <a href="yoga.php">
                    <img src="images/yoga_final.png" alt="project image">
                    </a>
                  </div>                
                   <p class="project-title">YOGA</p>
                </div>

                <div class="project-container">
                  <div class="project-img-container" display='block'>
                    <a href="streaching.php">
                    <img src="images/strech.png" alt="project image">
                  </div>
                  </a>
                   <p class="project-title">STRECHING</p>
                </div>

                
</body>
</html>