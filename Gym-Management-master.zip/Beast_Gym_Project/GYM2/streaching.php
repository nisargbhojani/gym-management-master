<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Streching</title>
    <style>
    .yt{
        margin-left:35%;
        margin-top:50px;
    }
    </style>
</head>
<body>
    <?php include('11.php') ?>
    <div class="yt">
    
    <iframe width="620" height="415"
        src="https://www.youtube.com/embed/VUL_SRmTejg" frameborder="0" allowfullscreen>
    </iframe>
    

    </div>
</body>
</html>