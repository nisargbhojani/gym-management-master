<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>H.I.I.T</title>
    <link rel="stylesheet" href="rope.css">
</head>
<body>
    <?php 
        include ('11.php');
    ?>

<div id="portfolio">
            <section class="clearfix">

              <div class="project-section">

                <div class="project-container">
                  <div class="project-img-container" display='block'>
                      <a href="#">
                    <img src="2.jpg" alt="project image">
                    </a>
                </div>
                  <p class="project-title">...</p>
                </div>

                <div class="project-container">
                  <div class="project-img-container" display='block'>
                      <a href="#">
                    <img src="1.jpg" alt="project image">
                    </a>
                  </div>
                  <p class="project-title">SIT-UPS</p>
                </div>

                <div class="project-container">
                  <div class="project-img-container" display='block'>
                    <img src="2.jpg" alt="project image">
                  </div>
                   <p class="project-title">CRUNCHES</p>
                </div>

                <div class="project-container">
                  <div class="project-img-container" display='block'>
                    <img src="3.jpg" alt="project image">
                  </div>
                   <p class="project-title">JUMP</p>
                </div>

                <div class="project-container">
                  <div class="project-img-container" display='block'>
                    <img src="3.jpg" alt="project image">
                  </div>
                   <p class="project-title">ROPE</p>
                </div>

                <div class="project-container">
                  <div class="project-img-container" display='block'>
                    <img src="3.jpg" alt="project image">
                  </div>
                   <p class="project-title">LEGS</p>
                </div>
</body>
</html>