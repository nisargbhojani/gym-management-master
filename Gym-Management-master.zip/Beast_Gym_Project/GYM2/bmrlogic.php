<link rel="stylesheet" href="indextest.css">
<div class="container">
<?php
// process data submitted in form
  if(isset($_POST['givems']) && ($_POST['givems'])== "Submit"){
  // extract the data and assign automatically to variables
  extract($_POST);
    // make sure all fields have been filled in with proper answers or are not blank
    if($age != '' && $weight != '' && $height != '' && $activitylevel != 'Pick one') { 
        // determine if using standard or metric
       if($unit == 'Standard') {
        // use the standard variations of the code
        // next determine exact formula based on user's gender
        if($gender == 'Female') {
            $pre_bmr = 655.1 + (4.35*$weight) + (4.7*$height) - (4.7*$age);
   
            // now multiply that value by the user's lifestyle, format it & announce it
                 if($activitylevel == 'Sedentary') {
                 $mult_bmr = $pre_bmr*1.2;
                 $bmr = number_format($mult_bmr,0);
                 $lose1 = number_format($mult_bmr - 500);
                 echo "<center>Your Basal Metabolic Rate is $bmr calories a day. <br /> To lose one pound a week, your caloric budget would be $lose1 calories every day.</center><br /><br />";
                 } elseif($activitylevel == 'Light') {
                 $mult_bmr = $pre_bmr*1.375;
                 $bmr = number_format($mult_bmr,0);
                 $lose1 = number_format($mult_bmr - 500);
                 echo "<center>Your Basal Metabolic Rate is $bmr calories a day. <br /> To lose one pound a week, your caloric budget would be $lose1 calories every day.</center><br /><br />";
                 } elseif($activitylevel == 'Moderate') {
                 $mult_bmr = $pre_bmr*1.55;
                 $bmr = number_format($mult_bmr,0);
                 $lose1 = number_format($mult_bmr - 500);
                 echo "<center>Your Basal Metabolic Rate is $bmr calories a day. <br /> To lose one pound a week, your caloric budget would be $lose1 calories every day.</center><br /><br />";
                 } elseif($activitylevel == 'Very') {
                 $mult_bmr = $pre_bmr*1.725;
                 $bmr = number_format($mult_bmr,0);
                 $lose1 = number_format($mult_bmr - 500);
                 echo "<center>Your Basal Metabolic Rate is $bmr calories a day. <br /> To lose one pound a week, your caloric budget would be $lose1 calories every day.</center><br /><br />";
                 } elseif($activitylevel == 'Extremely') {
                 $mult_bmr = $pre_bmr*1.9;
                 $bmr = number_format($mult_bmr,0);
                 $lose1 = number_format($mult_bmr - 500);
                 echo "<center>Your Basal Metabolic Rate is $bmr calories a day. <br /> To lose one pound a week, your caloric budget would be $lose1 calories every day.</center><br /><br />";
                 }          

            } elseif($gender=='Male') {
            $pre_bmr = 066 + (6.2*$weight) + (12.7*$height) - (6.76*$age);
            // now multiply that value by the user's lifestyle, format it & announce it
                 if($activitylevel == 'Sedentary') {
                 $mult_bmr = $pre_bmr*1.2;
                 $bmr = number_format($mult_bmr,0);
                 $lose1 = number_format($mult_bmr - 500);
                 echo "<center>Your Basal Metabolic Rate is $bmr calories a day. <br /> To lose one pound a week, your caloric budget would be $lose1 calories every day.</center><br /><br />";
                 } elseif($activitylevel == 'Light') {
                 $mult_bmr = $pre_bmr*1.375;
                 $bmr = number_format($mult_bmr,0);
                 $lose1 = number_format($mult_bmr - 500);
                 echo "<center>Your Basal Metabolic Rate is $bmr calories a day. <br /> To lose one pound a week, your caloric budget would be $lose1 calories every day.</center><br /><br />";
                 } elseif($activitylevel == 'Moderate') {
                 $mult_bmr = $pre_bmr*1.55;
                 $bmr = number_format($mult_bmr,0);
                 $lose1 = number_format($mult_bmr - 500);
                 echo "<center>Your Basal Metabolic Rate is $bmr calories a day. <br /> To lose one pound a week, your caloric budget would be $lose1 calories every day.</center><br /><br />";
                 } elseif($activitylevel == 'Very') {
                 $mult_bmr = $pre_bmr*1.725;
                 $bmr = number_format($mult_bmr,0);
                 $lose1 = number_format($mult_bmr - 500);
                 echo "<center>Your Basal Metabolic Rate is $bmr calories a day. <br /> To lose one pound a week, your caloric budget would be $lose1 calories every day.</center><br /><br />";
                 } elseif($activitylevel == 'Extremely') {
                 $mult_bmr = $pre_bmr*1.9;
                 $bmr = number_format($mult_bmr,0);
                 $lose1 = number_format($mult_bmr - 500);
                 echo "<center>Your Basal Metabolic Rate is $bmr calories a day. <br /> To lose one pound a week, your caloric budget would be $lose1 calories every day.</center><br /><br />";
                 }
            }
        } elseif($unit=='Metric') {
            // use the metric variation of the code
                 // next determine exact formula based on user's gender
                 if($gender=='Female') {
                 $pre_bmr = 655.1 + (9.563*$weight) + (1.850*$height) - (4.676*$age);
             
                      // now multiply that value by the user's lifestyle, format it & announce it
                           if($activitylevel == 'Sedentary') {
                           $mult_bmr = $pre_bmr*1.2;
                           $bmr = number_format($mult_bmr,0);
                           $lose1 = number_format($mult_bmr - 500);
                           echo "<center>Your Basal Metabolic Rate is $bmr calories a day. <br /> To lose one pound a week, your caloric budget would be $lose1 calories every day.</center><br /><br />";
                           } elseif($activitylevel == 'Light') {
                           $mult_bmr = $pre_bmr*1.375;
                           $bmr = number_format($mult_bmr,0);
                           $lose1 = number_format($mult_bmr - 500);
                           echo "<center>Your Basal Metabolic Rate is $bmr calories a day. <br /> To lose one pound a week, your caloric budget would be $lose1 calories every day.</center><br /><br />";
                           } elseif($activitylevel == 'Moderate') {
                           $mult_bmr = $pre_bmr*1.55;
                           $bmr = number_format($mult_bmr,0);
                           $lose1 = number_format($mult_bmr - 500);
                           echo "<center>Your Basal Metabolic Rate is $bmr calories a day. <br /> To lose one pound a week, your caloric budget would be $lose1 calories every day.</center><br /><br />";
                           } elseif($activitylevel == 'Very') {
                           $mult_bmr = $pre_bmr*1.725;
                           $bmr = number_format($mult_bmr,0);
                           $lose1 = number_format($mult_bmr - 500);
                           echo "<center>Your Basal Metabolic Rate is $bmr calories a day. <br /> To lose one pound a week, your caloric budget would be $lose1 calories every day.</center><br /><br />";
                           } elseif($activitylevel == 'Extremely') {
                           $mult_bmr = $pre_bmr*1.9;
                           $bmr = number_format($mult_bmr,0);
                           $lose1 = number_format($mult_bmr - 500);
                           echo "<center>Your Basal Metabolic Rate is $bmr calories a day. <br /> To lose one pound a week, your caloric budget would be $lose1 calories every day.</center><br /><br />";
                           }          
      
                      } elseif($gender=='Male') {
                      $pre_bmr = 66.5 + (13.75*$weight) + (5.003*$height) - (6.755*$age);
                      // now multiply that value by the user's lifestyle, format it & announce it
                           if($activitylevel == 'Sedentary') {
                           $mult_bmr = $pre_bmr*1.2;
                           $bmr = number_format($mult_bmr,0);
                           $lose1 = number_format($mult_bmr - 500);
                           echo "<center>Your Basal Metabolic Rate is $bmr calories a day. <br /> To lose one pound a week, your caloric budget would be $lose1 calories every day.</center><br /><br />";
                           } elseif($activitylevel == 'Light') {
                           $mult_bmr = $pre_bmr*1.375;
                           $bmr = number_format($mult_bmr,0);
                           $lose1 = number_format($mult_bmr - 500);
                           echo "<center>Your Basal Metabolic Rate is $bmr calories a day. <br /> To lose one pound a week, your caloric budget would be $lose1 calories every day.</center><br /><br />";
                           } elseif($activitylevel == 'Moderate') {
                           $mult_bmr = $pre_bmr*1.55;
                           $bmr = number_format($mult_bmr,0);
                           $lose1 = number_format($mult_bmr - 500);
                           echo "<center>Your Basal Metabolic Rate is $bmr calories a day. <br /> To lose one pound a week, your caloric budget would be $lose1 calories every day.</center><br /><br />";
                           } elseif($activitylevel == 'Very') {
                           $mult_bmr = $pre_bmr*1.725;
                           $bmr = number_format($mult_bmr,0);
                           $lose1 = number_format($mult_bmr - 500);
                           echo "<center>Your Basal Metabolic Rate is $bmr calories a day. <br /> To lose one pound a week, your caloric budget would be $lose1 calories every day.</center><br /><br />";
                           } elseif($activitylevel == 'Extremely') {
                           $mult_bmr = $pre_bmr*1.9;
                           $bmr = number_format($mult_bmr,0);
                           $lose1 = number_format($mult_bmr - 500);
                           echo "<center>Your Basal Metabolic Rate is $bmr calories a day. <br /> To lose one pound a week, your caloric budget would be $lose1 calories every day.</center><br /><br />";
                           }  // elseif activity level
      
                      } // elseif gender = male
        
            } // elseif unit is metric
             // handling form submission errors/inappropriate answers
    } elseif($activitylevel == 'Pick one') {
        echo "Please first select an activity level!";
      } elseif($age == '' || $weight =='' || $height == '') {
        echo "Please make sure all fields have been entered or selected!"; 
      }
     
    } // if post is submitted
  ?> 

</div>