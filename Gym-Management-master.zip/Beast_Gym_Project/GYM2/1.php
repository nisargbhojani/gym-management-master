<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="1.css">
    <title>Welcome</title>
</head>
<body>
    <div class="sidenav">
        <a href="#">My Profile</a>
        <a href="#">Diet Plans</a>
        <a href="#">Workout Plans</a>
        <a href="#">Workout Tuts</a>
        <a href="#">Trainer</a>
    </div>
    <div class="main">
        <h2>MY PROFILE </h2>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorem earum accusamus tempora. Consequatur, voluptate doloremque, cupiditate cum iste, excepturi sequi sint aut labore itaque perferendis sapiente praesentium. Sint iure similique eligendi magni, distinctio accusamus ipsam quas aperiam placeat vero harum magnam autem velit, aliquam blanditiis atque voluptas, optio voluptatem? Tempora velit sit, perferendis architecto ullam, reiciendis sed adipisci tenetur quo similique optio mollitia provident cumque.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolore fugit neque obcaecati ipsa ipsam harum dolor hic, at possimus iste fuga. Similique et nobis eos ad quis dicta libero dolores, perspiciatis itaque modi suscipit.</p>

    </div>
</html>