<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gym Name</title>
    <link rel="stylesheet" href="home.css">
</head>
<body>   
    <div class="back">
        <?php
            include ('header.php');
        ?> 
    <!-- <div class="main">
         <div class="logo">
            <img src="logo2.png" alt="gym">
        </div>
        <ul>
            <li class="active"><a href="#">Home</a></li>
            <li><a href="#">Services</a></li>
            <li><a href="#">About Us</a></li>
            <li><a href="#">Contact Us</a></li>
        </ul>
    </div> -->
    <div class="title">
        <h1>BEAST GYM</h1>
    </div>
    <div class="button">
        <a href="user_reg.php" class="btn">JOIN NOW</a>
        <a href="login.php" class="btn">LOGIN NOW</a>        
    </div>

    <!-- <div class="footer">
        <?php
        include "footer.php";
        ?>
    </div> -->
</div>
</body>
</html>