<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <link rel="stylesheet" href="userprofile.css">
</head>
<body>

    <?php
        // session_start();
        include('11.php');
        include "connect.php";
        $id=$_SESSION['SRno'];

        $sql="select * from `reg_data` where `userid`='".$id."' ";
       $query = mysqli_query($conn,$sql);
       $row = mysqli_fetch_array($query);
      
      
       
    
        $_SESSION['name']=$row['Name'];
        $_SESSION['email']=$row['Email'];
        $_SESSION['height']=$row['Height'];
        $_SESSION['weight']=$row['Weight'];
        $_SESSION['phonenumber']=$row['Phonenumber'];
        $_SESSION['Address']=$row['Address'];
        $_SESSION['Pincode']=$row['Pincode'];
        $_SESSION['Disease']=$row['Disease'];
        $_SESSION['State']=$row['State'];
        $_SESSION['City']=$row['City'];
        $_SESSION['password']=$row['Password'];
       
     
        // mysqli_free_result($query);
        mysqli_close($conn);


        if (isset($_POST['update_btn'])){
          
            include "connect.php";

           $id = $_SESSION['SRno'];



            $uname = $_POST['uname'];
            $height = $_POST['height'];
            $weight = $_POST['weight'];
            $phonenumber = $_POST['Phonenumber'];
            $Address = $_POST['Address'];
             $Pincode = $_POST['Pin-code'];
             $Disease= $_POST['Disease'];
              $State = $_POST['State'];
             $City = $_POST['City'];
        
        
            //  echo '<script>alert('.$height.')</script>';
        
        
        
            // $sql = "INSERT INTO `reg data` VALUES (NULL,'$name', '$email', '$height' ,'$weight' ,'$phonenumber','$Address','$Pincode','$Country', '$State','$City','$password' )";
            $sql = "UPDATE `reg_data` SET `Name`='$uname', `Height`='$height' , `Weight`='$weight' , `Phonenumber`='$phonenumber',`Address`='$Address', `Pincode`='$Pincode', `Disease`='Disease', `State`='$State',`City`='$City' WHERE `userid`='$id' ";
            $result = mysqli_query($conn, $sql);
        
            if($result){
              echo '<script>alert("Data Updated Successfully")</script>';
              //header("location: login.php");
            }
        
            else{
                // echo "The record was not inserted successfully because of this error ---> ". mysqli_error($conn);
                echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
              <strong>Error!</strong> We are facing some technical issue and your entry ws not submitted successfully! We regret the inconvinience caused!
              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">×</span>
              </button>
            </div>';
            }
        
          
            mysqli_close($conn);
        
        }
        
   
       
     
    
    ?>

    <div class="wrap">
        <h1>User Information</h1>    
        <form action="" method="POST">     
        <input value="<?php echo  $_SESSION['name'];?>" type="text" placeholder="Name" name="uname" id="name">      
        <input disabled="true" value="<?php echo  $_SESSION['email'] ;?>" type="text" placeholder="Email" name="email" id="email">        
        <input value="<?php  echo $_SESSION['height'] ;?>" type="number" placeholder="Height" name="height" id="height">
        <input value="<?php echo $_SESSION['weight'] ;?>" type="number" placeholder="Weight" name="weight" id="weight">
        <input value="<?php echo $_SESSION['phonenumber'] ;?>" type="number" placeholder="Phone Number" name="Phonenumber" id="Phonenumber">
        <input value="<?php echo $_SESSION['Address'] ;?>" type="text" placeholder="Address" name="Address" id="Address">
        <input value="<?php echo $_SESSION['Pincode'] ;?>" type="number" placeholder="Pincode" name="Pin-code" id="Pincode">
        <input value="<?php echo $_SESSION['Disease'] ;?>" type="text" placeholder="Disease" name="Disease" id="Disease">
        <input value="<?php echo $_SESSION['State'] ;?>" type="text" placeholder="State" name="State" id="State">
        <input value="<?php echo $_SESSION['City'] ;?>" type="text" placeholder="City" name="City" id="City">
        <!-- <input type="password" placeholder="" id="password">       -->
        <button type="submit" name="update_btn" class="registerbtn">Update Information</button>
        </form>
    </div>
    
</body>
</html>