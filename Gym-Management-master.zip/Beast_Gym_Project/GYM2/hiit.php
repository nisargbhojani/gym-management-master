<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>H.I.I.T</title>
    <link rel="stylesheet" href="hiit.css">
</head>
<body>
    <?php 
        include ('11.php');
    ?>

<div id="portfolio">
            <section class="clearfix">

              <div class="project-section">

                <div class="project-container">
                  <div class="project-img-container" display='block'>
                      <a href="hiit_push.php">
                    <img src="images/push_up.png" alt="project image">
                    </a>
                </div>
                  <p class="project-title">PUSH-UP</p>
                </div>

                <div class="project-container">
                  <div class="project-img-container" display='block'>
                      <a href="hiit_sit.php">
                    <img src="images/sit_ups.png" alt="project image">
                    </a>
                  </div>
                  <p class="project-title">SIT-UPS</p>
                </div>

                <div class="project-container">
                  <div class="project-img-container" display='block'>
                  <a href="hiit_burpee.php">
                    <img src="images/burpee.png" alt="project image">
                    </a>
                  </div>
                   <p class="project-title">BURPEE</p>
                </div>

                <div class="project-container">
                  <div class="project-img-container" display='block'>
                  <a href="hiit_russian.php">
                    <img src="images/russian_twist.png" alt="project image">
                    </a>
                  </div>
                   <p class="project-title">RUSSIAN TWIST</p>
                </div>

                <div class="project-container">
                  <div class="project-img-container" display='block'>
                  <a href="hiit_plank.php">
                    <img src="images/plank_jack.png" alt="project image">
                    </a>
                  </div>
                   <p class="project-title">PLANK JACK</p>
                </div>

                <div class="project-container">
                  <div class="project-img-container" display='block'>
                  <a href="hiit_mtn.php">
                    <img src="images/mtn_climb.png" alt="project image">
                    </a>
                  </div>
                   <p class="project-title">MOUNTAIN CLIMBER</p>
                </div>
</body>
</html>