<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us</title>
    <link rel="stylesheet" href="aboutus.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>   
    <?php
        include ('header.php')
    ?>
    <div class="container">
        <div class="aboutus">
            <h1>About Us</h1>
            <hr>
        </div>    
        <div class="para">
            <p style="font-size:25px;">Gym and club management systems provide fitness businesses the functionality to manage schedules, memberships, and facilities. The capabilities of gym management systems include storing member information in a database, managing financial records, scheduling classes, and reserving facilities.</p>
            <hr>
        </div>
        <div class="para">
            <p style="font-size:25px;">Gym and club management systems can be utilized by organizations in a variety of fitness-focused organizations and businesses.</p>
            <hr>
        </div>
    </div>
    <div class="footer">
        <!-- <?php
        include "footer.php";
        ?> -->
    </div>
</body>
</html>