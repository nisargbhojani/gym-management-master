<!doctype html>
<html>
<head>
<title>BMR Calculator script</title>
<link rel="stylesheet" type="text/css" href = "bmrcalc.css" />
</head>
<body>
   
    <?php
       include('11.php')
    ?>
    <div class="heading">
        <h3>BMR and Caloric Budget Calculator</h3>
    </div>
<div id="bmrbox">
<form id="bmrform" name="bmrform" method="post">
Select unit: <input type="radio" name="unit" value="Standard" checked> Standard
             <input type="radio" name="unit" value="Metric"> Metric <br /><br />
Gender: <input type="radio" name="gender" value="Male" checked> Male
        <input type="radio" name="gender" value="Female"> Female <br /><br />
Age: <input type="text" name="age" placeholder="Your Age"> <br /><br />
Weight: <input type="text" name="weight" placeholder="Your weight (in kg or lbs)"><br /><br />
Height: <input type="text" name="height" placeholder="Your height (in cm or inches)" size="22"><br /><br />
Your activity level:<br />
<select name="activitylevel" id="sel">
<option value="Pick one" checked> Pick an activity level!</option>
<option value="Sedentary"> Sedentary: Little to no exercise</option>
<option value="Light"> Light exercise: one to three days a week</option>
<option value="Moderate"> Moderately active: three to five days a week</option>
<option value="Very">Very active: vigorous exercise six to seven days a week</option>
<option value="Extremely">Extremely active: intense exercise six to seven days a week</option>
</select><br /><br />
<input type="submit" name="givems" id="givems" class="btn" value="Submit"/>
</form>
<?php
       require('bmrlogic.php')
    ?>
</div>
</body>
</html>