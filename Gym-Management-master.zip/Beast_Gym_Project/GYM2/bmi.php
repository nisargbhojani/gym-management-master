<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BMI</title>
    <link rel="stylesheet" href="bmi1.css">
</head>
<body>
<?php
include('11.php')
?>
<div class="container">
    <?php 
    if ($_GET['submit']) { 
    $mass = $_GET['mass'];
    $height = $_GET['height'];
    function bmi($mass,$height) {
    $bmi = $mass/($height*$height);
    return $bmi;
    } 
    $bmi = bmi($mass,$height);
    if ($bmi <= 18.5) {
    $output = "Under Weight";
    } else if ($bmi > 18.5 AND $bmi<=24.9 ) {
    $output = "Normal Weight";
    } else if ($bmi > 24.9 AND $bmi<=29.9) {
    $output = "Over Weight";
    } else if ($bmi > 30.0) {
    $output = "OBESE";
    }
    echo "Your BMI value is " . $bmi . " and you are : "; 
    echo "$output";
    }
?>

</div>
</body>
</html>

